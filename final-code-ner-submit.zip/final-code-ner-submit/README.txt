Final Code for Twitter NER project (UMass CS 585, Intro to NLP, Fall 2014)

DATA
train.txt + dev.txt — training set  (from github.com/aritter/twitter_nlp)
test_nolabels.txt -- test set (provided in class)
search.json —- search results from Freebase which we ended up not using for reasons mentioned in the report. 

CODE
simple_fe.py -- a simple feature extractor designed to be used with crfsuite. Modified for our project. 
tageval.py and other files from starter kit - not included
freebase.py —- our small experiment with the Freebase
ner.sh —- script to run all programs sequentially
train.feats —- to show what our features look like
test_nolabels.feats —- not included to prevent exceeding upload limit on moodle. Looks like vectors from train.feats, so provides not additional information from an evaluation perspective. 
50mpaths2.txt — not included, used for implementing the clusterID feature. 



